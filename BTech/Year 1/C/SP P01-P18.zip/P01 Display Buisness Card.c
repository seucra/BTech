/**************************************************
Display your own Buissness Card				
**************************************************/
#include <stdio.h>

int main()
{
	printf("****************************************************************************");
	printf("\n\t\t\tSHAMS TABREZ AHMED\n");
	printf("\t\tB.tech Computer Engineering\n\t\tData Scientist\n");
	printf("****************************************************************************");
	printf("\nPh no. - 91+ 1111111111\t\t\t|\tQualifications\n");
	printf("123 Termi Nator, near Pool Hospital\t|Mastry in Deep Learning\n");
	printf("Akoola, Alaska\t\t\t\t|Mastry in Data Handling |Mastry in Data Manipulation");
	return 0;
	
	
}

#include<stdio.h>
#include<conio.h>

int main()
{
	int a=5,s=2;
	printf((a<s)? "True" : "%dFalse",a);
}

/**************************************************
Display List of five programming languages reverse diagonally
**************************************************/
#include <stdio.h>

int main()
{
	printf("****************************************************************************");
	printf("\nDisplay List of five programming languages reverse diagonally\t\t\t****\n");
	printf("****************************************************************************");
	printf("\n\t\t\t\tHTML\t\t\t\t\t****\n\t\t\tJava\t\t\t\t\t\t****\n\t\tC++\t\t\t\t\t\t\t****\n\tC\t\t\t\t\t\t\t\t****\nPython\t\t\t\t\t\t\t\t\t****\n");
	printf("****************************************************************************");
	return 0;
	
}
